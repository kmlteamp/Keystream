# NCB KEY STREAM

Website cấp và xác thực KEY bằng Cloudflare Workers + D1.

## Tính năng
- Giao diện gaming màu đen/tím neon.
- Người dùng tạo KEY tự động, gắn với DEVICE ID của trình duyệt.
- Xác thực KEY qua backend.
- ADMIN tạo KEY, xem danh sách và khóa KEY.
- Thời hạn KEY tính theo giờ.

## Yêu cầu
- Tài khoản Cloudflare.
- Node.js và npm.
- Wrangler CLI (được cài qua `npm install`).

## 1. Tạo D1 database
Trong Cloudflare Dashboard, tạo D1 database tên `ncb-key-stream`.
Sao chép Database ID và điền vào `wrangler.toml` tại `database_id`.

## 2. Cài dependencies
```bash
npm install
```

## 3. Chạy migration
```bash
npx wrangler d1 migrations apply ncb-key-stream --remote
```

## 4. Đặt ADMIN_TOKEN
```bash
npx wrangler secret put ADMIN_TOKEN
```
Nhập một token bí mật dài, khó đoán. Không commit token vào GitHub và không gửi token cho người khác.

## 5. Chạy thử
```bash
npx wrangler dev
```

## 6. Deploy
```bash
npx wrangler deploy
```

Sau khi deploy, mở URL `*.workers.dev` mà Cloudflare cung cấp.

## API chính
- `GET /api/health` — kiểm tra máy chủ.
- `POST /api/issue` — cấp KEY cho DEVICE ID (mặc định 24 giờ).
- `POST /api/validate` — xác thực KEY.
- `GET /api/admin/keys` — xem danh sách (cần ADMIN_TOKEN).
- `POST /api/admin/keys` — ADMIN tạo KEY.
- `POST /api/admin/keys/:id/lock` — ADMIN khóa KEY.

ADMIN API dùng header:
```http
Authorization: Bearer YOUR_ADMIN_TOKEN
```

## Lưu ý bảo mật
- `ADMIN_TOKEN` phải được lưu bằng Cloudflare Secret, không ghi trực tiếp vào mã nguồn.
- DEVICE ID ở bản này được lưu trong localStorage của trình duyệt, không phải định danh phần cứng bất biến.
- Trước khi mở công khai, hãy bổ sung rate limiting/chống spam, bảo vệ admin bằng đăng nhập mạnh hơn và kiểm thử tải.
- KEY chỉ được hiển thị đầy đủ lúc tạo; database chỉ lưu SHA-256 hash của KEY.
