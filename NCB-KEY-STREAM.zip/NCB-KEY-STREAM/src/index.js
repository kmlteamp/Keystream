const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  }
});

function getDeviceId(value) {
  return typeof value === "string" && /^[a-f0-9-]{32,64}$/i.test(value)
    ? value : null;
}

function getKey(value) {
  return typeof value === "string" && /^NCB-[A-Z0-9-]{12,60}$/.test(value)
    ? value : null;
}

async function sha256(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}

function randomKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  const raw = [...bytes].map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
  return `NCB-${raw.match(/.{1,6}/g).join("-")}`;
}

function adminAuthorized(request, env) {
  const auth = request.headers.get("authorization") || "";
  return !!env.ADMIN_TOKEN && auth === `Bearer ${env.ADMIN_TOKEN}`;
}

async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}

async function issueKey(env, deviceId, hours) {
  const key = randomKey();
  const hash = await sha256(key);
  const now = Math.floor(Date.now() / 1000);
  const expires = now + hours * 3600;
  const id = crypto.randomUUID();

  await env.DB.prepare(
    `INSERT INTO keys (id, key_hash, key_prefix, device_id, status, created_at, expires_at)
     VALUES (?, ?, ?, ?, 'active', ?, ?)`
  ).bind(id, hash, key.slice(0, 10), deviceId, now, expires).run();

  return { key, expiresAt: expires };
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    try {
      if (path === "/api/health" && method === "GET") {
        await env.DB.prepare("SELECT 1").first();
        return json({ ok: true, service: "NCB KEY STREAM" });
      }

      // Người dùng tự lấy KEY; KEY được gắn với DEVICE ID của trình duyệt.
      if (path === "/api/issue" && method === "POST") {
        const body = await readJson(request);
        const deviceId = getDeviceId(body?.deviceId);
        const hours = Number(body?.hours ?? 24);
        if (!deviceId) return json({ error: "DEVICE ID không hợp lệ." }, 400);
        if (!Number.isInteger(hours) || hours < 1 || hours > 8760) {
          return json({ error: "Thời hạn phải từ 1 đến 8760 giờ." }, 400);
        }

        const existing = await env.DB.prepare(
          `SELECT id, status, expires_at FROM keys
           WHERE device_id = ? AND status = 'active' AND expires_at > ?
           ORDER BY created_at DESC LIMIT 1`
        ).bind(deviceId, Math.floor(Date.now() / 1000)).first();

        if (existing) {
          return json({ error: "Thiết bị này đã có KEY còn hạn. Hãy sử dụng KEY hiện tại." }, 409);
        }

        const result = await issueKey(env, deviceId, hours);
        return json({ ok: true, key: result.key, expiresAt: result.expiresAt });
      }

      // Xác thực KEY và ràng buộc KEY vào thiết bị ở lần xác thực đầu tiên.
      if (path === "/api/validate" && method === "POST") {
        const body = await readJson(request);
        const key = getKey(body?.key);
        const deviceId = getDeviceId(body?.deviceId);
        if (!key || !deviceId) return json({ valid: false, error: "KEY hoặc DEVICE ID không hợp lệ." }, 400);

        const hash = await sha256(key);
        const row = await env.DB.prepare(
          "SELECT id, device_id, status, expires_at FROM keys WHERE key_hash = ?"
        ).bind(hash).first();

        if (!row) return json({ valid: false, error: "KEY không tồn tại." }, 404);
        if (row.status !== "active") return json({ valid: false, error: "KEY đã bị khóa." }, 403);
        if (row.expires_at <= Math.floor(Date.now() / 1000)) {
          return json({ valid: false, error: "KEY đã hết hạn." }, 403);
        }
        if (row.device_id && row.device_id !== deviceId) {
          return json({ valid: false, error: "KEY đã được liên kết với thiết bị khác." }, 403);
        }
        if (!row.device_id) {
          await env.DB.prepare("UPDATE keys SET device_id = ? WHERE id = ? AND device_id IS NULL")
            .bind(deviceId, row.id).run();
        }
        return json({ valid: true, expiresAt: row.expires_at });
      }

      // Admin: xem danh sách KEY.
      if (path === "/api/admin/keys" && method === "GET") {
        if (!adminAuthorized(request, env)) return json({ error: "Không có quyền ADMIN." }, 401);
        const result = await env.DB.prepare(
          `SELECT id, key_prefix, device_id, status, created_at, expires_at, locked_at
           FROM keys ORDER BY created_at DESC LIMIT 200`
        ).all();
        return json({ keys: result.results || [] });
      }

      // Admin: tạo KEY thủ công, có thể gắn sẵn DEVICE ID.
      if (path === "/api/admin/keys" && method === "POST") {
        if (!adminAuthorized(request, env)) return json({ error: "Không có quyền ADMIN." }, 401);
        const body = await readJson(request);
        const hours = Number(body?.hours ?? 24);
        const deviceId = body?.deviceId ? getDeviceId(body.deviceId) : null;
        if (!Number.isInteger(hours) || hours < 1 || hours > 8760) {
          return json({ error: "Thời hạn phải từ 1 đến 8760 giờ." }, 400);
        }
        if (body?.deviceId && !deviceId) return json({ error: "DEVICE ID không hợp lệ." }, 400);
        const result = await issueKey(env, deviceId, hours);
        return json({ ok: true, key: result.key, expiresAt: result.expiresAt });
      }

      // Admin: khóa KEY theo ID bản ghi.
      const lockMatch = path.match(/^\/api\/admin\/keys\/([a-f0-9-]+)\/lock$/i);
      if (lockMatch && method === "POST") {
        if (!adminAuthorized(request, env)) return json({ error: "Không có quyền ADMIN." }, 401);
        const result = await env.DB.prepare(
          "UPDATE keys SET status = 'locked', locked_at = ? WHERE id = ?"
        ).bind(Math.floor(Date.now() / 1000), lockMatch[1]).run();
        if (!result.meta?.changes) return json({ error: "Không tìm thấy KEY." }, 404);
        return json({ ok: true });
      }

      if (path.startsWith("/api/")) return json({ error: "API không tồn tại." }, 404);

      return env.ASSETS.fetch(request);
    } catch (err) {
      return json({ error: "Máy chủ gặp lỗi. Vui lòng thử lại." }, 500);
    }
  }
};