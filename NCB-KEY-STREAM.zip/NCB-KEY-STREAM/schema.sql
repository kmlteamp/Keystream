CREATE TABLE IF NOT EXISTS keys (
  id TEXT PRIMARY KEY,
  key_hash TEXT NOT NULL UNIQUE,
  key_prefix TEXT NOT NULL,
  device_id TEXT,
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'locked')),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  locked_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_keys_device ON keys(device_id);
CREATE INDEX IF NOT EXISTS idx_keys_status_expiry ON keys(status, expires_at);
